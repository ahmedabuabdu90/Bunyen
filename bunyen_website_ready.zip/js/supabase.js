// Supabase client for بُنْيَان website
// Public anon key is safe to expose in client-side code (protected by RLS)
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

const SUPABASE_URL = 'https://clqtxqpagkjsiujwekjb.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNscXR4cXBhZ2tqc2l1andla2piIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEwNDQzNDMsImV4cCI6MjA5NjYyMDM0M30.oJeT_evq2gPLOQhEtJeqTriSc6LjMX-UxhqNMAQDmiI';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
